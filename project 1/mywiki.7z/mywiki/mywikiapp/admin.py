from django.contrib import admin
from .models import ImageEntry,textdata
# Register your models here.

admin.site.register(ImageEntry)
admin.site.register(textdata)