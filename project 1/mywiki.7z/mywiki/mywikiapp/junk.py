       
        # return HttpResponse("The Title already exists please try using another Title")       

         # return render(request,"mywikiapp/create_new.html",{"formimg":image_from_form}) 
       
       
        # filename = f"media/imagaes/{Title}.jpg"
        # if default_storage.exists(filename):
        #     default_storage.delete(filename)
        # default_storage.save(filename, ContentFile(newimg))
        
        # extension=os.path.splitext(img.name)[1]
        # filename=f"E:\web win\cs50\project 1\mywiki\asfs.jpg"
        
        # if newimg:
        #     with open(rf"media\images\manually\{newimg.name}","wb+") as f:
        #         for chunk in newimg.chunks():
        #             f.write(chunk)
    # return HttpResponse(f"this--{Title} and {Content} -----{(imgname)}--{print(type(imgname))}----")