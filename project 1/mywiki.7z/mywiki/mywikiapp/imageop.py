import markdown2
from markdown2 import markdown_path
from markdown2 import markdown
import webbrowser
import re

# txt='?q=naruto'
# print(re.findall(r'^[?]q=.*',txt))
# print(re.findall(r'http.*',txt))
# markdowner=markdown_path()

x=markdown("**strike**")

print(x)

# x=markdown_path(r'E:\web win\cs50\project 1\mywiki\media\entries\india.md')

# print(x)
# webbrowser.open(x)

# with open(rf"E:\web win\cs50\project 1\mywiki\media\entries\{title}.md","r") as f:
#         conv_html=f.read
        