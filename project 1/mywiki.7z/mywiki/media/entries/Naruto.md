#Naruto
**IMAGE**
___
![NARUTO](/media/images/170712.jpg)

This article is about the episodes in the Naruto: Shippuden series. For the list of episodes from the original Naruto series, see List of Naruto episodes.
Key visual of the series.

Naruto: Shippuden is an anime series mainly adapted from Part II of Masashi Kishimoto's original manga series, with exactly 500 episodes. It is set two and a half years after the original series in the Naruto universe, following the ninja teenager Naruto Uzumaki and his allies. The series is directed by Hayato Date, and produced by Pierrot and TV Tokyo. It began broadcasting on February 15, 2007 on TV Tokyo, and concluded on March 23, 2017.[1][2]

On January 2, 2009, Viz Media and Crunchyroll provided eight uncut English subtitled Naruto: Shippuden episodes on the official Naruto website.[3] Later on January 15, Viz began providing subtitled versions of the latest Naruto: Shippuden episodes a week after they first aired in Japan, with a new episode being added to the Naruto website each subsequent Thursday.[3] The English dub of Naruto: Shippuden made its US premiere on Disney XD on October 28, 2009.[4][5][6] On July 24, 2009, Viz Media announced that the series would be released on the iTunes Store.[7] The first DVD release of the series in North America was released on September 29, 2009.[8]

Naruto: Shippuden stopped airing on Disney XD on November 5, 2011 after 98 episodes, in which the network cited more frequent violence that was shown in later episodes.[9] DVD box sets generally containing thirteen dubbed episodes from episode 1 onward were released quarterly in their uncut format.[10][11] The English dub was streamed on the Neon Alley web channel from its launch in October 2012, and beginning December 29, 2012 with episode 99, dubbed episodes premiered every week uncut until March 25, 2016 after 338 episodes, about a month before Neon Alley's closure. Adult Swim's Toonami programming block began airing the anime from the beginning on January 5, 2014 in an uncut format and as of 2022 it is still running on a weekly basis.[12] The network started showing never before aired dubbed episodes at the 339th episode mark by May 2021.

In four regions, episodes from the series have been released on DVD and Blu-ray by single volumes and box sets. In North America, twelve single volumes and thirty eight box sets have been released. In the United Kingdom, twenty eight single volumes and six box sets have been released. In Japan, twenty six sets of volumes have been released based on which arc it represents. In Australia and New Zealand, twenty-eight collections have been released. 
