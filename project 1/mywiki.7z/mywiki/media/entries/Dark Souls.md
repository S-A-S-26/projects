#Dark Souls

![img](/media/images/cropped-1600-900-530706.jpg)

**_Dark Souls_**[a] is a series of action role-playing games created by [Hidetaka Miyazaki](https://en.wikipedia.org/wiki/Hidetaka_Miyazaki) of [FromSoftware](https://en.wikipedia.org/wiki/FromSoftware) and published by Bandai Namco Entertainment. The series began with the release of Dark Souls in 2011 and has seen two sequels, Dark Souls II (2014) and Dark Souls III (2016). Other FromSoftware games, including Demon's Souls, King's Field, Bloodborne, Sekiro, and Elden Ring, share several related concepts and are commonly grouped together as Soulslikes.

Dark Souls has received critical acclaim, with the first game often cited as one of the greatest in video games. The series has been both praised and criticized for its high level of difficulty. By 2021, the series had shipped nearly 30 million copies